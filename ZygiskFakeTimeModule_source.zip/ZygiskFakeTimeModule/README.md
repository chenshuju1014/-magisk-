# Zygisk Fake Time V4 Safe

Per-app fake wall-clock time for selected packages/processes.

## Safety changes in V4

- Uses `targets.txt` as a very small allowlist.
- Non-target processes immediately call `DLCLOSE_MODULE_LIBRARY` and do not hook, scan, start threads, or keep file descriptors.
- No background rescan thread.
- No second-level config reload.
- `cycle` mode is computed in memory and does not require reloading config.

## Files after installation

```text
/data/adb/modules/zygisk_faketime/targets.txt
/data/adb/modules/zygisk_faketime/config.json
```

## targets.txt

One package/process name per line:

```text
com.zyyad.game
```

Changing `targets.txt` requires force-stopping and reopening the target app. It does not require rebooting the phone.

## config.json

```json
{
  "enabled": true,
  "mode": "cycle",
  "fake_start": "2026-06-14 11:00:00",
  "cycle_start": "2026-06-14 11:00:00",
  "cycle_end": "2026-06-14 12:00:00",
  "timezone_offset_minutes": 480,
  "hook_monotonic": false
}
```

Modes:

- `fixed`: always returns `fake_start`.
- `flow`: returns `fake_start + real elapsed time since target process start`.
- `cycle`: cycles between `cycle_start` and `cycle_end`; `fake_start` controls the starting phase.

Changing `config.json` requires force-stopping and reopening the target app. Cycle rollback itself does **not** require restart.

## What it hooks

PLT hooks in the target process only:

- `time`
- `gettimeofday`
- `clock_gettime`
- realtime clocks only by default

`hook_monotonic` should normally remain `false`; turning it on may break animations, timers, media playback, or networking.

## Build with GitHub Actions

Upload the whole `ZygiskFakeTimeModule` folder or use the included workflow. The output artifact is an outer zip; the flashable Magisk module is `zygisk_faketime_v4_safe.zip` inside the artifact.
