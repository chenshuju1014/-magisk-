# Zygisk Fake Time v0.2-rescan

This version rescans /proc/self/maps after app startup, so native libraries loaded later by game engines can also be PLT-hooked.

Build with the included GitHub Actions workflow, then flash the produced Magisk/KernelSU module zip.

Config path after install:

```
/data/adb/modules/zygisk_faketime/config.json
```

Change config and force-stop/reopen target app. Reboot is only needed after installing/updating the module.
