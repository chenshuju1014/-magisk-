# Zygisk Fake Time（源码工程，不是可直接刷入包）

目标：只在配置文件列出的 App 进程里伪装“墙上时间”（wall clock），用于影响 `time()` / `gettimeofday()` / `clock_gettime(CLOCK_REALTIME)` 一类 native 时间源。

> 重要：这个压缩包是源码工程，不包含已编译 `.so`，所以不是可直接刷入的 Magisk 模块。需要用 Android NDK 编译，或用本项目自带的 GitHub Actions 自动构建出可刷入 zip。

## 配置文件

模块安装后配置文件放在：

```text
/data/adb/modules/zygisk_faketime/config.json
```

示例：

```json
{
  "enabled": true,
  "targets": ["com.zyyad.game"],
  "mode": "flow",
  "fake_start": "2026-06-14 11:00:00",
  "cycle_start": "2026-06-14 11:00:00",
  "cycle_end": "2026-06-14 12:00:00",
  "timezone_offset_minutes": 480,
  "reload_interval_ms": 1000,
  "hook_monotonic": false
}
```

字段说明：

- `enabled`: 总开关。
- `targets`: 生效包名列表。比如 `["com.zyyad.game", "com.example.app"]`。
- `mode`: `fixed` / `flow` / `cycle`。
- `fake_start`: 固定/流动模式的起始假时间；循环模式里用作循环起点内的初始相位，如果不在区间内则从 `cycle_start` 开始。
- `cycle_start`: 循环开始时间。
- `cycle_end`: 循环结束时间。例：11:00 到 12:00，到 12:00 后回到 11:00。
- `timezone_offset_minutes`: 你写入的日期字符串按哪个时区解释。中国时区用 480。
- `reload_interval_ms`: 运行中重新读取配置的间隔。改时间配置后通常不用重启手机，目标 App 内大约 1 秒后生效；但修改 `targets` 对尚未 Hook 的进程需要强制停止并重新打开 App。
- `hook_monotonic`: 默认 `false`。不建议打开。打开后可能影响动画、倒计时、性能计时。

## 三种模式

### fixed

目标 App 永远看到同一个时间：

```json
"mode": "fixed",
"fake_start": "2026-06-14 11:30:00"
```

### flow

目标 App 看到的时间从假时间开始，按现实经过时间继续流动：

```json
"mode": "flow",
"fake_start": "2026-06-14 11:30:00"
```

比如 App 启动时是假 11:30，现实过 10 分钟后，App 看到 11:40。

### cycle

目标 App 看到的时间在区间内循环：

```json
"mode": "cycle",
"cycle_start": "2026-06-14 11:00:00",
"cycle_end": "2026-06-14 12:00:00",
"fake_start": "2026-06-14 11:00:00"
```

效果：11:00 → 12:00 → 11:00 → 12:00 循环。

## 重要限制

1. 只 Hook native 层通过 PLT 调用的 `time/gettimeofday/clock_gettime`。如果目标使用 syscall/vDSO/自己缓存时间，可能绕过本模块。
2. 不改全局系统时间，只影响配置里的目标 App 进程。
3. 改 `targets` 后，需要强制停止并重新打开对应 App；不需要重启手机。
4. 改 `fake_start/mode/cycle_*` 后，模块会定期重新读取配置，通常不需要重启 App。
5. 这是底层 Hook，写错配置一般不会变砖，但可能导致目标 App 闪退。保留一个能进 Recovery/Magisk 的退路。

## 构建

项目源自 Magisk/Zygisk 官方模块结构：Magisk 文档说明 Zygisk 可让模块在 App 进程 specialization 前后运行，官方 sample 也要求用 Android NDK 编译。

### GitHub Actions 自动构建

1. 新建一个 GitHub 仓库。
2. 把本源码包内容上传进去。
3. 进入 Actions，运行 `Build Zygisk FakeTime`。
4. 下载 artifact 里的 `zygisk_faketime.zip`。
5. Magisk 里刷入该 zip，重启手机。
6. 确认 Magisk 开启 Zygisk。

### 本地构建

进入 `module/jni`：

```bash
$ANDROID_NDK_HOME/ndk-build
```

把生成的：

```text
module/libs/arm64-v8a/libzygisk_faketime.so
module/libs/armeabi-v7a/libzygisk_faketime.so
```

分别复制为：

```text
module/zygisk/arm64-v8a.so
module/zygisk/armeabi-v7a.so
```

然后打包 `module` 目录内容为 Magisk 模块 zip。
