编译后把 so 放在这里：
arm64-v8a.so
armeabi-v7a.so

源码包不包含预编译 so，所以不能直接刷入。
