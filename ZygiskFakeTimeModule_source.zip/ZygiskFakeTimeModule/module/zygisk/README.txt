Compiled files go here after GitHub Actions build:
zygisk/arm64-v8a.so
zygisk/armeabi-v7a.so
