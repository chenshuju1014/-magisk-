LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := zygisk_faketime
LOCAL_SRC_FILES := main.cpp
LOCAL_CFLAGS := -Wall -Wextra -Wno-unused-parameter -fvisibility=hidden
LOCAL_CPPFLAGS := -std=c++17 -fno-exceptions -fno-rtti
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)
