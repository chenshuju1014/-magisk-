#include "zygisk.hpp"

#include <android/log.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/sysmacros.h>
#include <time.h>
#include <unistd.h>

#define LOG_TAG "ZygiskFakeTimeV4"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef CLOCK_REALTIME_COARSE
#define CLOCK_REALTIME_COARSE 5
#endif
#ifndef CLOCK_BOOTTIME
#define CLOCK_BOOTTIME 7
#endif

struct Config {
    bool enabled;
    bool hook_monotonic;
    char mode[16];
    int64_t fake_start_ms;
    int64_t cycle_start_ms;
    int64_t cycle_end_ms;
    int timezone_offset_minutes;
};

static zygisk::Api *g_api = nullptr;
static JNIEnv *g_env = nullptr;
static char g_process_name[192] = {0};
static bool g_target_process = false;
static Config g_cfg;
static int64_t g_process_start_mono_ms = 0;

static time_t (*orig_time_fn)(time_t *tloc) = nullptr;
static int (*orig_gettimeofday_fn)(struct timeval *tv, struct timezone *tz) = nullptr;
static int (*orig_clock_gettime_fn)(clockid_t clk_id, struct timespec *tp) = nullptr;

static int64_t raw_clock_gettime_ms(clockid_t clk) {
    struct timespec ts{};
    int r;
    // Use syscall here deliberately: this should reflect real monotonic/realtime,
    // and avoids recursion when our own PLT hooks are active.
    r = (int) syscall(__NR_clock_gettime, clk, &ts);
    if (r != 0) return 0;
    return (int64_t) ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

static int64_t real_mono_ms() {
    return raw_clock_gettime_ms(CLOCK_MONOTONIC);
}

// Howard Hinnant's civil calendar algorithm, public domain style.
static int64_t days_from_civil(int y, unsigned m, unsigned d) {
    y -= m <= 2;
    const int era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097LL + (int64_t)doe - 719468LL;
}

static bool parse_datetime_to_ms(const char *s, int tz_offset_minutes, int64_t *out_ms) {
    int y=0, mo=0, d=0, h=0, mi=0, sec=0;
    if (!s || !out_ms) return false;
    if (sscanf(s, "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &sec) != 6) return false;
    if (y < 1970 || mo < 1 || mo > 12 || d < 1 || d > 31 || h < 0 || h > 23 || mi < 0 || mi > 59 || sec < 0 || sec > 60) return false;
    int64_t days = days_from_civil(y, (unsigned)mo, (unsigned)d);
    int64_t utc_sec = days * 86400LL + h * 3600LL + mi * 60LL + sec - (int64_t)tz_offset_minutes * 60LL;
    *out_ms = utc_sec * 1000LL;
    return true;
}

static const char *skip_ws(const char *p) {
    while (p && *p && isspace((unsigned char)*p)) ++p;
    return p;
}

static bool json_get_bool(const char *json, const char *key, bool def) {
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) return def;
    p = strchr(p, ':');
    if (!p) return def;
    p = skip_ws(p + 1);
    if (strncmp(p, "true", 4) == 0) return true;
    if (strncmp(p, "false", 5) == 0) return false;
    return def;
}

static int json_get_int(const char *json, const char *key, int def) {
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) return def;
    p = strchr(p, ':');
    if (!p) return def;
    p = skip_ws(p + 1);
    char *end = nullptr;
    long v = strtol(p, &end, 10);
    if (end == p) return def;
    return (int)v;
}

static bool json_get_string(const char *json, const char *key, char *out, size_t out_sz, const char *def) {
    if (!out || out_sz == 0) return false;
    out[0] = 0;
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) {
        if (def) snprintf(out, out_sz, "%s", def);
        return false;
    }
    p = strchr(p, ':');
    if (!p) {
        if (def) snprintf(out, out_sz, "%s", def);
        return false;
    }
    p = skip_ws(p + 1);
    if (*p != '"') {
        if (def) snprintf(out, out_sz, "%s", def);
        return false;
    }
    ++p;
    size_t n = 0;
    while (*p && *p != '"' && n + 1 < out_sz) out[n++] = *p++;
    out[n] = 0;
    return n > 0;
}

static ssize_t read_file_at(int dirfd, const char *name, char *buf, size_t cap) {
    if (dirfd < 0 || !name || !buf || cap == 0) return -1;
    int fd = openat(dirfd, name, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    ssize_t total = 0;
    while ((size_t)total + 1 < cap) {
        ssize_t r = read(fd, buf + total, cap - 1 - (size_t)total);
        if (r < 0) {
            if (errno == EINTR) continue;
            close(fd);
            return -1;
        }
        if (r == 0) break;
        total += r;
    }
    buf[total] = 0;
    close(fd);
    return total;
}

static bool line_matches_pkg(const char *line, const char *pkg) {
    if (!line || !pkg || !*pkg) return false;
    while (*line && isspace((unsigned char)*line)) ++line;
    if (*line == 0 || *line == '#') return false;
    char item[192];
    size_t n = 0;
    while (*line && *line != '\n' && *line != '\r' && *line != '#' && n + 1 < sizeof(item)) {
        item[n++] = *line++;
    }
    while (n > 0 && isspace((unsigned char)item[n - 1])) --n;
    item[n] = 0;
    return strcmp(item, pkg) == 0;
}

static bool targets_txt_contains(int module_fd, const char *pkg) {
    char buf[4096];
    ssize_t n = read_file_at(module_fd, "targets.txt", buf, sizeof(buf));
    if (n <= 0) return false;
    const char *p = buf;
    while (*p) {
        const char *line = p;
        const char *nl = strchr(p, '\n');
        char tmp[256];
        if (!nl) {
            snprintf(tmp, sizeof(tmp), "%s", line);
            p += strlen(p);
        } else {
            size_t len = (size_t)(nl - line);
            if (len >= sizeof(tmp)) len = sizeof(tmp) - 1;
            memcpy(tmp, line, len);
            tmp[len] = 0;
            p = nl + 1;
        }
        if (line_matches_pkg(tmp, pkg)) return true;
    }
    return false;
}

static bool parse_config_text(const char *json, Config *out) {
    if (!json || !out) return false;
    Config c{};
    c.enabled = json_get_bool(json, "enabled", true);
    c.hook_monotonic = json_get_bool(json, "hook_monotonic", false);
    c.timezone_offset_minutes = json_get_int(json, "timezone_offset_minutes", 480);
    json_get_string(json, "mode", c.mode, sizeof(c.mode), "flow");

    char fake[64], cs[64], ce[64];
    json_get_string(json, "fake_start", fake, sizeof(fake), "2026-06-14 11:00:00");
    json_get_string(json, "cycle_start", cs, sizeof(cs), "2026-06-14 11:00:00");
    json_get_string(json, "cycle_end", ce, sizeof(ce), "2026-06-14 12:00:00");
    if (!parse_datetime_to_ms(fake, c.timezone_offset_minutes, &c.fake_start_ms)) return false;
    if (!parse_datetime_to_ms(cs, c.timezone_offset_minutes, &c.cycle_start_ms)) return false;
    if (!parse_datetime_to_ms(ce, c.timezone_offset_minutes, &c.cycle_end_ms)) return false;
    *out = c;
    return true;
}

static void set_default_config(Config *c) {
    memset(c, 0, sizeof(*c));
    c->enabled = true;
    c->hook_monotonic = false;
    snprintf(c->mode, sizeof(c->mode), "%s", "flow");
    c->timezone_offset_minutes = 480;
    parse_datetime_to_ms("2026-06-14 11:00:00", 480, &c->fake_start_ms);
    parse_datetime_to_ms("2026-06-14 11:00:00", 480, &c->cycle_start_ms);
    parse_datetime_to_ms("2026-06-14 12:00:00", 480, &c->cycle_end_ms);
}

static int64_t fake_realtime_ms() {
    if (!g_cfg.enabled) return raw_clock_gettime_ms(CLOCK_REALTIME);
    int64_t elapsed = real_mono_ms() - g_process_start_mono_ms;
    if (strcmp(g_cfg.mode, "fixed") == 0) {
        return g_cfg.fake_start_ms;
    }
    if (strcmp(g_cfg.mode, "cycle") == 0) {
        int64_t start = g_cfg.cycle_start_ms;
        int64_t end = g_cfg.cycle_end_ms;
        int64_t dur = end - start;
        if (dur <= 0) return g_cfg.fake_start_ms;
        int64_t phase = 0;
        if (g_cfg.fake_start_ms >= start && g_cfg.fake_start_ms < end) phase = g_cfg.fake_start_ms - start;
        int64_t x = (phase + elapsed) % dur;
        if (x < 0) x += dur;
        return start + x;
    }
    // flow mode: fake_start + real elapsed since target app process start.
    return g_cfg.fake_start_ms + elapsed;
}

extern "C" time_t fake_time(time_t *tloc) {
    time_t sec = (time_t)(fake_realtime_ms() / 1000LL);
    if (tloc) *tloc = sec;
    return sec;
}

extern "C" int fake_gettimeofday(struct timeval *tv, struct timezone *tz) {
    if (!tv) {
        if (orig_gettimeofday_fn) return orig_gettimeofday_fn(tv, tz);
        return (int) syscall(__NR_gettimeofday, tv, tz);
    }
    int64_t ms = fake_realtime_ms();
    tv->tv_sec = (time_t)(ms / 1000LL);
    tv->tv_usec = (suseconds_t)((ms % 1000LL) * 1000LL);
    if (tz) memset(tz, 0, sizeof(*tz));
    return 0;
}

extern "C" int fake_clock_gettime(clockid_t clk_id, struct timespec *tp) {
    if (!tp) {
        if (orig_clock_gettime_fn) return orig_clock_gettime_fn(clk_id, tp);
        return (int) syscall(__NR_clock_gettime, clk_id, tp);
    }
    if (clk_id == CLOCK_REALTIME || clk_id == CLOCK_REALTIME_COARSE ||
        (g_cfg.hook_monotonic && (clk_id == CLOCK_MONOTONIC || clk_id == CLOCK_BOOTTIME))) {
        int64_t ms;
        if (clk_id == CLOCK_REALTIME || clk_id == CLOCK_REALTIME_COARSE) {
            ms = fake_realtime_ms();
        } else {
            // Optional and normally discouraged. Keep monotonic relative to fake_start.
            ms = fake_realtime_ms();
        }
        tp->tv_sec = (time_t)(ms / 1000LL);
        tp->tv_nsec = (long)((ms % 1000LL) * 1000000LL);
        return 0;
    }
    if (orig_clock_gettime_fn) return orig_clock_gettime_fn(clk_id, tp);
    return (int) syscall(__NR_clock_gettime, clk_id, tp);
}

struct SeenMap { dev_t dev; ino_t ino; };
static SeenMap g_seen[1024];
static int g_seen_count = 0;

static bool seen_or_add(dev_t dev, ino_t ino) {
    for (int i = 0; i < g_seen_count; ++i) {
        if (g_seen[i].dev == dev && g_seen[i].ino == ino) return true;
    }
    if (g_seen_count < (int)(sizeof(g_seen) / sizeof(g_seen[0]))) {
        g_seen[g_seen_count].dev = dev;
        g_seen[g_seen_count].ino = ino;
        ++g_seen_count;
    }
    return false;
}

static int install_plt_hooks_once() {
    if (!g_api || !g_target_process) return 0;
    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;
    char line[1024];
    int registered = 0;
    while (fgets(line, sizeof(line), fp)) {
        char perms[8] = {0};
        unsigned int maj = 0, min = 0;
        unsigned long long inode_ull = 0;
        char path[512] = {0};
        int n = sscanf(line, "%*s %7s %*s %x:%x %llu %511s", perms, &maj, &min, &inode_ull, path);
        if (n < 4) continue;
        if (perms[0] != 'r' || perms[2] != 'x') continue;
        if (inode_ull == 0) continue;
        if (n >= 5 && strstr(path, "/zygisk_faketime") != nullptr) continue;
        dev_t dev = makedev(maj, min);
        ino_t ino = (ino_t)inode_ull;
        if (seen_or_add(dev, ino)) continue;
        g_api->pltHookRegister(dev, ino, "time", (void*)fake_time, (void**)&orig_time_fn);
        g_api->pltHookRegister(dev, ino, "__time", (void*)fake_time, (void**)&orig_time_fn);
        g_api->pltHookRegister(dev, ino, "gettimeofday", (void*)fake_gettimeofday, (void**)&orig_gettimeofday_fn);
        g_api->pltHookRegister(dev, ino, "__gettimeofday", (void*)fake_gettimeofday, (void**)&orig_gettimeofday_fn);
        g_api->pltHookRegister(dev, ino, "clock_gettime", (void*)fake_clock_gettime, (void**)&orig_clock_gettime_fn);
        g_api->pltHookRegister(dev, ino, "__clock_gettime", (void*)fake_clock_gettime, (void**)&orig_clock_gettime_fn);
#if defined(__arm__) || defined(__i386__)
        g_api->pltHookRegister(dev, ino, "clock_gettime64", (void*)fake_clock_gettime, (void**)&orig_clock_gettime_fn);
        g_api->pltHookRegister(dev, ino, "__clock_gettime64", (void*)fake_clock_gettime, (void**)&orig_clock_gettime_fn);
#endif
        registered++;
    }
    fclose(fp);
    if (registered <= 0) return 0;
    bool ok = g_api->pltHookCommit();
    LOGI("target=%s hooks registered_maps=%d commit=%d mode=%s", g_process_name, registered, ok ? 1 : 0, g_cfg.mode);
    return ok ? registered : 0;
}

class FakeTimeModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override {
        g_api = api;
        g_env = env;
    }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        g_target_process = false;
        g_process_name[0] = 0;
        g_seen_count = 0;
        if (!args || !args->nice_name || !g_env || !g_api) return;

        const char *name = g_env->GetStringUTFChars(args->nice_name, nullptr);
        if (name) {
            snprintf(g_process_name, sizeof(g_process_name), "%s", name);
            g_env->ReleaseStringUTFChars(args->nice_name, name);
        }
        if (g_process_name[0] == 0) {
            g_api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
            return;
        }

        int module_fd = g_api->getModuleDir();
        if (module_fd < 0) {
            g_api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
            return;
        }

        bool is_target = targets_txt_contains(module_fd, g_process_name);
        if (!is_target) {
            close(module_fd);
            g_api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
            return;
        }

        set_default_config(&g_cfg);
        char cfg_text[8192];
        if (read_file_at(module_fd, "config.json", cfg_text, sizeof(cfg_text)) > 0) {
            Config parsed;
            if (parse_config_text(cfg_text, &parsed)) g_cfg = parsed;
        }
        close(module_fd);

        if (!g_cfg.enabled) {
            g_api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
            return;
        }

        g_target_process = true;
        g_process_start_mono_ms = real_mono_ms();
        LOGI("target matched: %s mode=%s", g_process_name, g_cfg.mode);
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *args) override {
        (void)args;
        if (!g_target_process) return;
        install_plt_hooks_once();
    }
};

REGISTER_ZYGISK_MODULE(FakeTimeModule)
