#include "zygisk.hpp"

#include <android/log.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif
#include <time.h>
#include <unistd.h>
#include <sys/sysmacros.h>
#include <pthread.h>

#define LOG_TAG "ZygiskFakeTime"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifndef CLOCK_REALTIME_COARSE
#define CLOCK_REALTIME_COARSE 5
#endif
#ifndef CLOCK_BOOTTIME
#define CLOCK_BOOTTIME 7
#endif

struct Config {
    bool enabled;
    char mode[16];
    int64_t fake_start_ms;
    int64_t cycle_start_ms;
    int64_t cycle_end_ms;
    int timezone_offset_minutes;
    int reload_interval_ms;
};

static zygisk::Api *g_api = nullptr;
static JNIEnv *g_env = nullptr;
static int g_module_dir_fd = -1;
static char g_pkg[160] = {0};
static bool g_target_process = false;
static Config g_cfg;
static int64_t g_process_start_mono_ms = 0;
static int64_t g_last_reload_mono_ms = -1;
static pthread_t g_hook_thread;
static bool g_hook_thread_started = false;

static time_t (*orig_time_fn)(time_t *tloc) = nullptr;
static int (*orig_gettimeofday_fn)(struct timeval *tv, struct timezone *tz) = nullptr;
static int (*orig_clock_gettime_fn)(clockid_t clk_id, struct timespec *tp) = nullptr;

static int64_t sys_clock_gettime_ms(clockid_t clk) {
    struct timespec ts{};
    int r;
    if (orig_clock_gettime_fn) {
        r = orig_clock_gettime_fn(clk, &ts);
    } else {
        r = (int) syscall(__NR_clock_gettime, clk, &ts);
    }
    if (r != 0) return 0;
    return (int64_t) ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL;
}

static int64_t real_mono_ms() {
    return sys_clock_gettime_ms(CLOCK_MONOTONIC);
}

static int64_t days_from_civil(int y, unsigned m, unsigned d) {
    y -= m <= 2;
    const int era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097LL + (int64_t)doe - 719468LL;
}

static bool parse_datetime_to_ms(const char *s, int tz_offset_minutes, int64_t *out_ms) {
    int y=0, mo=0, d=0, h=0, mi=0, sec=0;
    if (sscanf(s, "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &sec) != 6) return false;
    if (y < 1970 || mo < 1 || mo > 12 || d < 1 || d > 31 || h < 0 || h > 23 || mi < 0 || mi > 59 || sec < 0 || sec > 60) return false;
    int64_t days = days_from_civil(y, (unsigned)mo, (unsigned)d);
    int64_t utc_sec = days * 86400LL + h * 3600LL + mi * 60LL + sec - (int64_t)tz_offset_minutes * 60LL;
    *out_ms = utc_sec * 1000LL;
    return true;
}

static const char *skip_ws(const char *p) {
    while (p && *p && isspace((unsigned char)*p)) ++p;
    return p;
}

static bool json_get_bool(const char *json, const char *key, bool def) {
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) return def;
    p = strchr(p, ':');
    if (!p) return def;
    p = skip_ws(p + 1);
    if (strncmp(p, "true", 4) == 0) return true;
    if (strncmp(p, "false", 5) == 0) return false;
    return def;
}

static int json_get_int(const char *json, const char *key, int def) {
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) return def;
    p = strchr(p, ':');
    if (!p) return def;
    p = skip_ws(p + 1);
    char *end = nullptr;
    long v = strtol(p, &end, 10);
    if (end == p) return def;
    return (int)v;
}

static bool json_get_string(const char *json, const char *key, char *out, size_t out_sz, const char *def) {
    if (!out || out_sz == 0) return false;
    out[0] = 0;
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(json, pat);
    if (!p) {
        if (def) snprintf(out, out_sz, "%s", def);
        return false;
    }
    p = strchr(p, ':');
    if (!p) {
        if (def) snprintf(out, out_sz, "%s", def);
        return false;
    }
    p = skip_ws(p + 1);
    if (*p != '"') {
        if (def) snprintf(out, out_sz, "%s", def);
        return false;
    }
    ++p;
    size_t n = 0;
    while (*p && *p != '"' && n + 1 < out_sz) {
        out[n++] = *p++;
    }
    out[n] = 0;
    return n > 0;
}

static bool json_targets_contains(const char *json, const char *pkg) {
    const char *p = strstr(json, "\"targets\"");
    if (!p) return false;
    p = strchr(p, '[');
    if (!p) return false;
    const char *end = strchr(p, ']');
    if (!end) return false;
    while (p < end) {
        p = strchr(p, '"');
        if (!p || p >= end) break;
        ++p;
        char item[160];
        size_t n = 0;
        while (*p && *p != '"' && p < end && n + 1 < sizeof(item)) item[n++] = *p++;
        item[n] = 0;
        if (strcmp(item, pkg) == 0) return true;
        if (*p == '"') ++p;
    }
    return false;
}

static ssize_t read_file_at(int dirfd, const char *name, char *buf, size_t cap) {
    if (cap == 0) return -1;
    int fd = openat(dirfd, name, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    ssize_t total = 0;
    while ((size_t)total + 1 < cap) {
        ssize_t r = read(fd, buf + total, cap - 1 - (size_t)total);
        if (r < 0) {
            if (errno == EINTR) continue;
            close(fd);
            return -1;
        }
        if (r == 0) break;
        total += r;
    }
    buf[total] = 0;
    close(fd);
    return total;
}

static bool parse_config_text(const char *json, Config *out) {
    if (!json || !out) return false;
    Config c{};
    c.enabled = json_get_bool(json, "enabled", true);
    c.timezone_offset_minutes = json_get_int(json, "timezone_offset_minutes", 480);
    c.reload_interval_ms = json_get_int(json, "reload_interval_ms", 1000);
    if (c.reload_interval_ms < 100) c.reload_interval_ms = 100;
    if (c.reload_interval_ms > 60000) c.reload_interval_ms = 60000;

    json_get_string(json, "mode", c.mode, sizeof(c.mode), "flow");
    char fake[64], cs[64], ce[64];
    json_get_string(json, "fake_start", fake, sizeof(fake), "2026-06-14 11:00:00");
    json_get_string(json, "cycle_start", cs, sizeof(cs), "2026-06-14 11:00:00");
    json_get_string(json, "cycle_end", ce, sizeof(ce), "2026-06-14 12:00:00");
    if (!parse_datetime_to_ms(fake, c.timezone_offset_minutes, &c.fake_start_ms)) return false;
    if (!parse_datetime_to_ms(cs, c.timezone_offset_minutes, &c.cycle_start_ms)) return false;
    if (!parse_datetime_to_ms(ce, c.timezone_offset_minutes, &c.cycle_end_ms)) return false;
    *out = c;
    return true;
}

static bool reload_config_now() {
    if (g_module_dir_fd < 0) return false;
    char buf[8192];
    ssize_t n = read_file_at(g_module_dir_fd, "config.json", buf, sizeof(buf));
    if (n <= 0) return false;
    Config c;
    if (!parse_config_text(buf, &c)) return false;
    g_cfg = c;
    return true;
}

static void maybe_reload_config() {
    int64_t now = real_mono_ms();
    if (g_last_reload_mono_ms < 0 || now - g_last_reload_mono_ms >= g_cfg.reload_interval_ms) {
        if (reload_config_now()) {
            g_last_reload_mono_ms = now;
        } else {
            g_last_reload_mono_ms = now;
        }
    }
}

static int64_t fake_realtime_ms() {
    maybe_reload_config();
    if (!g_cfg.enabled) {
        // Disabled: return real wall clock through syscall/original path.
        return sys_clock_gettime_ms(CLOCK_REALTIME);
    }
    int64_t elapsed = real_mono_ms() - g_process_start_mono_ms;
    if (strcmp(g_cfg.mode, "fixed") == 0) {
        return g_cfg.fake_start_ms;
    }
    if (strcmp(g_cfg.mode, "cycle") == 0) {
        int64_t start = g_cfg.cycle_start_ms;
        int64_t end = g_cfg.cycle_end_ms;
        int64_t dur = end - start;
        if (dur <= 0) return g_cfg.fake_start_ms;
        int64_t phase = 0;
        if (g_cfg.fake_start_ms >= start && g_cfg.fake_start_ms < end) phase = g_cfg.fake_start_ms - start;
        int64_t x = (phase + elapsed) % dur;
        if (x < 0) x += dur;
        return start + x;
    }
    // Default: flow
    return g_cfg.fake_start_ms + elapsed;
}

extern "C" time_t fake_time(time_t *tloc) {
    time_t sec = (time_t)(fake_realtime_ms() / 1000LL);
    if (tloc) *tloc = sec;
    return sec;
}

extern "C" int fake_gettimeofday(struct timeval *tv, struct timezone *tz) {
    if (!tv) {
        if (orig_gettimeofday_fn) return orig_gettimeofday_fn(tv, tz);
        return (int) syscall(__NR_gettimeofday, tv, tz);
    }
    int64_t ms = fake_realtime_ms();
    tv->tv_sec = (time_t)(ms / 1000LL);
    tv->tv_usec = (suseconds_t)((ms % 1000LL) * 1000LL);
    if (tz) {
        if (orig_gettimeofday_fn) return orig_gettimeofday_fn(nullptr, tz);
        memset(tz, 0, sizeof(*tz));
    }
    return 0;
}

extern "C" int fake_clock_gettime(clockid_t clk_id, struct timespec *tp) {
    if (!tp) {
        if (orig_clock_gettime_fn) return orig_clock_gettime_fn(clk_id, tp);
        return (int) syscall(__NR_clock_gettime, clk_id, tp);
    }
    if (clk_id == CLOCK_REALTIME || clk_id == CLOCK_REALTIME_COARSE) {
        int64_t ms = fake_realtime_ms();
        tp->tv_sec = (time_t)(ms / 1000LL);
        tp->tv_nsec = (long)((ms % 1000LL) * 1000000LL);
        return 0;
    }
    if (orig_clock_gettime_fn) return orig_clock_gettime_fn(clk_id, tp);
    return (int) syscall(__NR_clock_gettime, clk_id, tp);
}

struct SeenMap { dev_t dev; ino_t ino; };
static SeenMap g_seen[1024];
static int g_seen_count = 0;

static bool seen_or_add(dev_t dev, ino_t ino) {
    for (int i = 0; i < g_seen_count; ++i) {
        if (g_seen[i].dev == dev && g_seen[i].ino == ino) return true;
    }
    if (g_seen_count < (int)(sizeof(g_seen)/sizeof(g_seen[0]))) {
        g_seen[g_seen_count].dev = dev;
        g_seen[g_seen_count].ino = ino;
        ++g_seen_count;
    }
    return false;
}

static int install_plt_hooks_once() {
    if (!g_api) return 0;
    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) {
        LOGE("cannot open maps");
        return 0;
    }
    char line[1024];
    int registered = 0;
    while (fgets(line, sizeof(line), fp)) {
        char perms[8] = {0};
        unsigned int maj = 0, min = 0;
        unsigned long long inode_ull = 0;
        char path[512] = {0};
        int n = sscanf(line, "%*s %7s %*s %x:%x %llu %511s", perms, &maj, &min, &inode_ull, path);
        if (n < 4) continue;
        if (perms[0] != 'r' || perms[2] != 'x') continue;
        if (inode_ull == 0) continue;
        if (n >= 5) {
            // Skip anonymous maps and our module path is harmless, but avoiding it reduces noise.
            if (strstr(path, "/zygisk_faketime") != nullptr) continue;
        }
        dev_t dev = makedev(maj, min);
        ino_t ino = (ino_t) inode_ull;
        if (seen_or_add(dev, ino)) continue;
        g_api->pltHookRegister(dev, ino, "time", (void*) fake_time, (void**) &orig_time_fn);
        g_api->pltHookRegister(dev, ino, "__time", (void*) fake_time, (void**) &orig_time_fn);
        g_api->pltHookRegister(dev, ino, "gettimeofday", (void*) fake_gettimeofday, (void**) &orig_gettimeofday_fn);
        g_api->pltHookRegister(dev, ino, "__gettimeofday", (void*) fake_gettimeofday, (void**) &orig_gettimeofday_fn);
        g_api->pltHookRegister(dev, ino, "clock_gettime", (void*) fake_clock_gettime, (void**) &orig_clock_gettime_fn);
        g_api->pltHookRegister(dev, ino, "__clock_gettime", (void*) fake_clock_gettime, (void**) &orig_clock_gettime_fn);
        registered++;
    }
    fclose(fp);
    if (registered <= 0) return 0;
    bool ok = g_api->pltHookCommit();
    LOGI("package=%s PLT hooks newly_registered_maps=%d commit=%d", g_pkg, registered, ok ? 1 : 0);
    return ok ? registered : 0;
}

static void *hook_rescan_thread(void *) {
    // First seconds matter: game engines often dlopen native libs after Activity start.
    // Scan frequently at first, then keep a light periodic scan for later-loaded SDK/libs.
    for (int i = 0; i < 40; ++i) {
        install_plt_hooks_once();
        usleep(250 * 1000);
    }
    while (true) {
        install_plt_hooks_once();
        sleep(5);
    }
    return nullptr;
}

static void start_hook_thread() {
    if (g_hook_thread_started) return;
    g_hook_thread_started = true;
    int r = pthread_create(&g_hook_thread, nullptr, hook_rescan_thread, nullptr);
    if (r == 0) {
        pthread_detach(g_hook_thread);
        LOGI("package=%s hook rescan thread started", g_pkg);
    } else {
        LOGE("package=%s failed to start hook thread: %d", g_pkg, r);
    }
}

class FakeTimeModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override {
        g_api = api;
        g_env = env;
    }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        g_target_process = false;
        g_pkg[0] = 0;
        if (!args || !args->nice_name || !g_env) return;
        const char *name = g_env->GetStringUTFChars(args->nice_name, nullptr);
        if (name) {
            snprintf(g_pkg, sizeof(g_pkg), "%s", name);
            g_env->ReleaseStringUTFChars(args->nice_name, name);
        }
        if (g_pkg[0] == 0) return;

        g_module_dir_fd = g_api ? g_api->getModuleDir() : -1;
        if (g_module_dir_fd >= 0 && g_api) {
            g_api->exemptFd(g_module_dir_fd);
        }

        // Load config once before deciding whether to hook this process.
        Config default_cfg{};
        default_cfg.enabled = true;
        snprintf(default_cfg.mode, sizeof(default_cfg.mode), "%s", "flow");
        default_cfg.timezone_offset_minutes = 480;
        default_cfg.reload_interval_ms = 1000;
        parse_datetime_to_ms("2026-06-14 11:00:00", 480, &default_cfg.fake_start_ms);
        parse_datetime_to_ms("2026-06-14 11:00:00", 480, &default_cfg.cycle_start_ms);
        parse_datetime_to_ms("2026-06-14 12:00:00", 480, &default_cfg.cycle_end_ms);
        g_cfg = default_cfg;

        char buf[8192];
        bool match = false;
        if (g_module_dir_fd >= 0 && read_file_at(g_module_dir_fd, "config.json", buf, sizeof(buf)) > 0) {
            parse_config_text(buf, &g_cfg);
            match = json_targets_contains(buf, g_pkg);
        } else {
            match = strcmp(g_pkg, "com.zyyad.game") == 0;
        }
        g_target_process = match && g_cfg.enabled;
        g_process_start_mono_ms = real_mono_ms();
        g_last_reload_mono_ms = -1;

        if (!g_target_process && g_api) {
            g_api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
        } else {
            LOGI("target package matched: %s mode=%s", g_pkg, g_cfg.mode);
        }
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *args) override {
        (void) args;
        if (!g_target_process) return;
        install_plt_hooks_once();
        start_hook_thread();
    }
};

REGISTER_ZYGISK_MODULE(FakeTimeModule)
