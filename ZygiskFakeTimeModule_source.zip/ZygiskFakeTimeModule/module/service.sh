#!/system/bin/sh
MODDIR=${0%/*}
chmod 0644 "$MODDIR/config.json" 2>/dev/null
