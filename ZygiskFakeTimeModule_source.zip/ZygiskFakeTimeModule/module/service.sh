#!/system/bin/sh
MODDIR=${0%/*}
# No daemon, no background polling, no global process scanning.
exit 0
