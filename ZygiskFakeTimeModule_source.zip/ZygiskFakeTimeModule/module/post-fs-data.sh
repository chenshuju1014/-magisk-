#!/system/bin/sh
MODDIR=${0%/*}
CONFIG="$MODDIR/config.json"
if [ ! -f "$CONFIG" ]; then
  cat > "$CONFIG" <<'JSON'
{
  "enabled": true,
  "targets": ["com.zyyad.game"],
  "mode": "flow",
  "fake_start": "2026-06-14 11:00:00",
  "cycle_start": "2026-06-14 11:00:00",
  "cycle_end": "2026-06-14 12:00:00",
  "timezone_offset_minutes": 480,
  "reload_interval_ms": 1000,
  "hook_monotonic": false
}
JSON
fi
chmod 0644 "$CONFIG"
