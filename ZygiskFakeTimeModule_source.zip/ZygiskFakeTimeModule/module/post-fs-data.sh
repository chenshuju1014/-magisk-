#!/system/bin/sh
MODDIR=${0%/*}
# Keep scripts intentionally empty. The module is active through Zygisk only.
exit 0
